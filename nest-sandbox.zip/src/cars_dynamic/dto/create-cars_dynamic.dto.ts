export class CreateCarsDynamicDto {}
